package uml2;

public class Movie {
	
	boolean isRented;
	int price;
	
	public Movie(boolean isRented, int price) {
		this.isRented = isRented;
		this.price = price;
	}
	
	public String rentStatus() {
		
		if(isRented ==  true) {
		return "RENTED";
		}
		else {
		return "NOT RENTED";	
		}
		
	}
	
	public void rentMovie(User user1) {
		if(rentStatus() == "RENTED") {
			System.out.println("This movie is already rented");
		}else {
		if(user1.getType() == "Subscriber") {
		isRented = true;
		user1.addCredit(price);
		}else {
			System.out.println("Only subsribers can rent movies");
		}
		}
	}
		
	public void buyMovie(User user1) {
		isRented = true;
		user1.addCredit(price);
	}

}
