package uml2;

public class User {
	
	String type;
	static int credit = 0;

	public User(String type, int credit) {
		this.type = type;
		this.credit = credit;
	}
	
	public static void addCredit(int added) {
		credit = credit + added;
	}
	
	public String getType() {
		return type;
	}
}
