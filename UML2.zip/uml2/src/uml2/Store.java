package uml2;

public class Store {

	public static void main(String[] args) {
		
		User user1 = new User("Subscriber", 0);
		User user2 = new User("User", 0);
		Movie movie1 = new Movie(false, 10);
		
		movie1.rentMovie(user1);

	}

}
